package com.harindra.iptvpro

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.util.Log
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

/**
 * RAM PLAYER v27.0 — Zero-ANR Instant FFmpeg Auto-Heal Engine (LibVLC 3.6.5).
 * Strictly invoked ONLY when Media3 encounters AC3 6ch / 1080i50 / unsupported codec channels
 * (e.g., Zee Cinema HD, Sony Max HD, Star Gold HD). Normal channels stay on 0.25s Pure Media3!
 */
class LiveTvLibVlcEngine(context: Context) {

    data class VlcAudioTrack(val id: Int, val name: String, val isSelected: Boolean)

    interface Callbacks {
        fun onOpening()
        fun onBuffering(percent: Float)
        fun onPlaying()
        fun onFirstVideoFrame(width: Int, height: Int)
        fun onTracksUpdated(audioSummary: String)
        fun onError(reason: String)
        fun onEnded()
    }

    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())
    private val vlcThread = HandlerThread("RamPlayer-LibVlcWorker").apply { start() }
    private val vlcHandler = Handler(vlcThread.looper)

    @Volatile private var libVlc: LibVLC? = null
    @Volatile private var mediaPlayer: MediaPlayer? = null
    @Volatile private var attachedLayout: VLCVideoLayout? = null
    @Volatile private var callbacks: Callbacks? = null
    @Volatile private var softwareMode: Boolean = false
    @Volatile private var firstFrameSent: Boolean = false
    @Volatile private var playingNow: Boolean = false

    fun setCallbacks(cb: Callbacks?) {
        callbacks = cb
    }

    fun isSoftwareMode(): Boolean = softwareMode
    fun isPlaying(): Boolean = playingNow

    fun attachVideoLayout(layout: VLCVideoLayout) {
        attachedLayout = layout
        mainHandler.post {
            runCatching {
                val mp = mediaPlayer ?: return@runCatching
                if (!mp.vlcVout.areViewsAttached()) {
                    mp.attachViews(layout, null, false, false)
                }
            }
        }
    }

    fun playLiveStream(
        cleanUrl: String,
        forceSoftware: Boolean,
        headers: Map<String, String> = emptyMap(),
        networkCachingMs: Int = SmartChannelIntelligenceEngine.MIN_LIBVLC_CACHE_MS
    ) {
        softwareMode = forceSoftware
        firstFrameSent = false
        playingNow = false
        val safeCache = networkCachingMs.coerceIn(
            SmartChannelIntelligenceEngine.MIN_LIBVLC_CACHE_MS,
            SmartChannelIntelligenceEngine.MAX_LIBVLC_CACHE_MS
        )
        vlcHandler.removeCallbacksAndMessages(null)
        vlcHandler.post {
            runCatching {
                ensureInstanceLocked()
                val vlc = libVlc ?: return@runCatching
                val mp = mediaPlayer ?: return@runCatching
                runCatching { mp.stop() }

                val layout = attachedLayout
                if (layout != null) {
                    mainHandler.post {
                        runCatching {
                            if (!mp.vlcVout.areViewsAttached()) {
                                mp.attachViews(layout, null, false, false)
                            }
                        }
                    }
                }

                val media = Media(vlc, Uri.parse(cleanUrl)).apply {
                    setHWDecoderEnabled(!forceSoftware, false)
                    addOption(":network-caching=$safeCache")
                    addOption(":live-caching=300")
                    addOption(":file-caching=250")
                    addOption(":clock-jitter=0")
                    addOption(":clock-synchro=0")
                    addOption(":no-ts-cc-check")
                    addOption(":no-ts-trust-pcr")
                    addOption(":avcodec-skiploopfilter=1")
                    if (forceSoftware) {
                        addOption(":codec=avcodec,all")
                    }
                    headers["User-Agent"]?.takeIf { it.isNotBlank() }?.let { addOption(":http-user-agent=$it") }
                    headers["Referer"]?.takeIf { it.isNotBlank() }?.let { addOption(":http-referrer=$it") }
                }
                mp.media = media
                media.release()
                mp.play()
            }.onFailure { err ->
                Log.w("StreamX", "LibVLC playLiveStream error", err)
                mainHandler.post { callbacks?.onError(err.message ?: "LibVLC init error") }
            }
        }
    }

    private fun ensureInstanceLocked() {
        if (libVlc != null && mediaPlayer != null) return
        val args = arrayListOf(
            "--no-drop-late-frames",
            "--no-skip-frames",
            "--no-ts-cc-check",
            "--no-ts-trust-pcr",
            "--avcodec-hw=any",
            "--avcodec-skiploopfilter=1",
            "--live-caching=300",
            "--file-caching=250",
            "--aout=opensles",
            "--audio-time-stretch",
            "-v"
        )
        val vlc = LibVLC(appContext, args)
        val mp = MediaPlayer(vlc)
        mp.setEventListener { ev ->
            when (ev.type) {
                MediaPlayer.Event.Opening -> mainHandler.post { callbacks?.onOpening() }
                MediaPlayer.Event.Buffering -> mainHandler.post { callbacks?.onBuffering(ev.buffering) }
                MediaPlayer.Event.Playing -> {
                    playingNow = true
                    mainHandler.post { callbacks?.onPlaying() }
                }
                MediaPlayer.Event.Vout -> {
                    if (ev.voutCount > 0 && !firstFrameSent) {
                        firstFrameSent = true
                        val track = runCatching { mp.currentVideoTrack }.getOrNull()
                        val w = track?.width ?: 1280
                        val h = track?.height ?: 720
                        val audioName = runCatching {
                            mp.audioTracks?.firstOrNull { it.id == mp.audioTrack }?.name.orEmpty()
                        }.getOrDefault("")
                        mainHandler.post {
                            callbacks?.onFirstVideoFrame(w, h)
                            if (audioName.isNotBlank()) callbacks?.onTracksUpdated(audioName)
                        }
                    }
                }
                MediaPlayer.Event.EncounteredError -> {
                    playingNow = false
                    mainHandler.post { callbacks?.onError("LibVLC stream error") }
                }
                MediaPlayer.Event.EndReached -> {
                    playingNow = false
                    mainHandler.post { callbacks?.onEnded() }
                }
            }
        }
        libVlc = vlc
        mediaPlayer = mp
    }

    fun getAudioTracks(): List<VlcAudioTrack> {
        return runCatching {
            val mp = mediaPlayer ?: return emptyList()
            val activeId = mp.audioTrack
            mp.audioTracks?.filter { it.id >= 0 }?.map {
                VlcAudioTrack(it.id, it.name ?: "Audio ${it.id}", it.id == activeId)
            } ?: emptyList()
        }.getOrDefault(emptyList())
    }

    fun selectAudioTrack(trackId: Int) {
        vlcHandler.post { runCatching { mediaPlayer?.audioTrack = trackId } }
    }

    fun setAudioDelayMs(delayMs: Long) {
        vlcHandler.post { runCatching { mediaPlayer?.audioDelay = delayMs * 1000L } }
    }

    fun setAspectRatioByResizeIndex(resizeIndex: Int) {
        vlcHandler.post {
            runCatching {
                val mp = mediaPlayer ?: return@runCatching
                mp.scale = 0f
                mp.aspectRatio = when (resizeIndex) {
                    1 -> "16:9"
                    2 -> "21:9"
                    else -> null
                }
            }
        }
    }

    fun pause() {
        playingNow = false
        vlcHandler.post { runCatching { mediaPlayer?.pause() } }
    }

    fun stop() {
        playingNow = false
        vlcHandler.removeCallbacksAndMessages(null)
        vlcHandler.post { runCatching { mediaPlayer?.stop() } }
    }

    fun release() {
        playingNow = false
        callbacks = null
        vlcHandler.removeCallbacksAndMessages(null)
        vlcHandler.post {
            runCatching {
                mediaPlayer?.stop()
                mediaPlayer?.detachViews()
                mediaPlayer?.release()
            }
            runCatching { libVlc?.release() }
            mediaPlayer = null
            libVlc = null
            runCatching { vlcThread.quitSafely() }
        }
    }
}
