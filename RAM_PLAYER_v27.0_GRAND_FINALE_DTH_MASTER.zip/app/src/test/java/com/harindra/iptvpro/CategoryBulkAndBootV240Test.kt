package com.harindra.iptvpro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Unit tests for RAM PLAYER v24.0 Zero-ANR Bulk Category Engine:
 * - 1-Tap "Keep Only Selected" on 150 Xtream categories (keep 10 -> delete 140)
 * - 15,000-channel filtering accuracy with 140 excluded categories
 * - Case-insensitive and whitespace-safe category matching
 */
class CategoryBulkAndBootV240Test {

    @Test
    fun keepOnly10Of150CategoriesComputesExact140Deletions() {
        val allCategories = (1..150).map { idx -> "CAT_${idx.toString().padStart(3, '0')}" }
        val keepCategories = (1..10).map { idx -> "cat_${idx.toString().padStart(3, '0')} " }

        val toDelete = ChannelDeletionFilter.computeKeepOnlyDeletionSet(
            allActiveCategories = allCategories,
            categoriesToKeep = keepCategories
        )

        assertEquals(140, toDelete.size)
        assertFalse(toDelete.contains("CAT_001"))
        assertFalse(toDelete.contains("CAT_010"))
        assertTrue(toDelete.contains("CAT_011"))
        assertTrue(toDelete.contains("CAT_150"))
    }

    @Test
    fun filtering15000ChannelsWith140DeletedCategoriesKeepsOnlyRemaining1000() {
        val rawChannels = ArrayList<Channel>(15_000)
        val allCategories = (1..150).map { "GROUP_$it" }
        var idCounter = 1
        for (cat in allCategories) {
            repeat(100) {
                rawChannels.add(
                    Channel(
                        id = "ch_$idCounter",
                        number = idCounter,
                        name = "Channel $idCounter",
                        category = cat,
                        streamUrl = "http://demo.tv/live/u/p/$idCounter.ts",
                        sourceType = ContentSourceType.XTREAM_LIVE
                    )
                )
                idCounter++
            }
        }

        val keep = (1..10).map { "GROUP_$it" }
        val toDelete = ChannelDeletionFilter.computeKeepOnlyDeletionSet(allCategories, keep).toSet()
        assertEquals(140, toDelete.size)

        val remaining = ChannelDeletionFilter.filterActiveChannels(
            rawChannels = rawChannels,
            deletedCategories = toDelete,
            deletedChannelKeys = emptySet(),
            deletedChannelIds = emptySet()
        )

        assertEquals(1_000, remaining.size)
        assertTrue(remaining.all { it.category in keep })
    }

    @Test
    fun emptyKeepListNeverDeletesAnything() {
        val allCategories = listOf("INDIA", "SPORTS", "MOVIES")
        val toDelete = ChannelDeletionFilter.computeKeepOnlyDeletionSet(allCategories, emptyList())
        assertTrue(toDelete.isEmpty())
    }
}
